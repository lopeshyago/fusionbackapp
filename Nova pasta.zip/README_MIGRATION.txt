Fusion Fitness migrated for VPS (local backend). Frontend on 3001, backend on 4001.
Run: ./deploy_fusion_fitness.sh
Three users created: admin@fusion.com, instrutor@fusion.com, aluno@fusion.com (password: 123456)
